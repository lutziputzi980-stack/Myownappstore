const CACHE = 'spielstore-v1';
const SHELL = ['./', 'index.html', 'manifest.json', 'icon-192.png', 'icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

function getGame(id) {
  return new Promise((res, rej) => {
    const r = indexedDB.open('spielstore', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('games', { keyPath: 'id' });
    r.onerror = () => rej(r.error);
    r.onsuccess = () => {
      const q = r.result.transaction('games').objectStore('games').get(id);
      q.onsuccess = () => res(q.result);
      q.onerror = () => rej(q.error);
    };
  });
}

async function toDataUrl(blob) {
  const b = new Uint8Array(await blob.arrayBuffer());
  let s = '';
  for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return 'data:image/png;base64,' + btoa(s);
}

// Eigenes Manifest pro Spiel -> jedes Spiel bekommt Name + Icon auf dem Home-Bildschirm
async function gameManifest(id) {
  const g = await getGame(id);
  if (!g) return new Response('{}', { status: 404 });
  const base = self.registration.scope;
  const start = base + '?play=' + encodeURIComponent(id);
  const icon = await toDataUrl(g.icon);
  return new Response(JSON.stringify({
    id: start,
    name: g.name,
    short_name: g.name.slice(0, 12),
    start_url: start,
    scope: base,
    display: 'standalone',
    background_color: '#0f0f14',
    theme_color: '#0f0f14',
    icons: [{ src: icon, sizes: '192x192 512x512', type: 'image/png', purpose: 'any' }]
  }), { headers: { 'Content-Type': 'application/manifest+json' } });
}

self.addEventListener('fetch', e => {
  const req = e.request;
  const u = new URL(req.url);
  if (u.origin !== location.origin) return;

  if (u.pathname.endsWith('/manifest.json') && u.searchParams.has('game')) {
    e.respondWith(gameManifest(u.searchParams.get('game')));
    return;
  }
  if (req.method !== 'GET') return;

  // Stale-while-revalidate: sofort aus dem Cache (funktioniert offline), im Hintergrund aktualisieren
  e.respondWith(caches.open(CACHE).then(async cache => {
    const key = new Request(u.origin + u.pathname);
    const cached = await cache.match(key);
    const net = fetch(req).then(r => {
      if (r.ok) cache.put(key, r.clone());
      return r;
    }).catch(() => cached);
    return cached || net;
  }));
});
